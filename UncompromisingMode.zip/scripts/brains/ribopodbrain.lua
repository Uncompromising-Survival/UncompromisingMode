require "behaviours/wander"
require "behaviours/doaction"
require "behaviours/chaseandattack"
require "behaviours/standstill"
require "behaviours/runaway"

local BrainCommon = require("brains/braincommon")

local STOP_RUN_DIST = 10
local SEE_PLAYER_DIST = 5
local MAX_WANDER_DIST = 20
local SEE_TARGET_DIST = 6

local MAX_CHASE_DIST = 7
local MAX_CHASE_TIME = 8

local function GoHomeAction(inst)
    if inst.components.homeseeker and
       inst.components.homeseeker.home and
       inst.components.homeseeker.home:IsValid() then
        return BufferedAction(inst, inst.components.homeseeker.home, ACTIONS.GOHOME)
    end
end

local function ShouldGoHome(inst) -- leave this node here incase we want to change it
    return false
end

local FINDFOOD_CANT_TAGS = { "outofreach", "INLIMBO" }
local function EatFoodAction(inst)
	 local target = FindEntity(inst,
        16,
        function(item)
            return item.components.edible ~= nil
				and not (item.components.burnable ~= nil and item.components.burnable:IsBurning())
                and item:IsOnPassablePoint()
				and item:IsOnValidGround()
				and not item:HasTag("insect")
                and (inst.components.eater ~= nil and inst.components.eater:CanEat(item))
        end,
        nil,
        FINDFOOD_CANT_TAGS
    )
    if target ~= nil then
		--TheNet:Announce("told to eat")
        return BufferedAction(inst, target, ACTIONS.EAT) or nil
    end
end

local HunterParams = {
    tags = {"scarytoprey"},
    notags = {"INLIMBO", "NOCLICK"},
}

local function HasFriends(inst)
	return inst.friend_tracking >= 3
end

local RibopodBrain = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

function RibopodBrain:OnStart()
    local root = PriorityNode(
    {
		BrainCommon.PanicTrigger(self.inst),
        BrainCommon.ElectricFencePanicTrigger(self.inst),
		WhileNode(function() return not HasFriends(self.inst) end, "ShouldGoHome",
			RunAway(self.inst, HunterParams, SEE_PLAYER_DIST, STOP_RUN_DIST, nil, true)),
        ChaseAndAttack(self.inst, MAX_CHASE_TIME),
		DoAction(self.inst, EatFoodAction, "eat food", true),
        -- WhileNode(function() return ShouldGoHome(self.inst) end, "ShouldGoHome",
            -- DoAction(self.inst, function() return GoHomeAction(self.inst) end, "go home", true )),
		Wander(self.inst, function() return self.inst.components.knownlocations:GetLocation("home") end, MAX_WANDER_DIST),

    }, .25)

    self.bt = BT(self.inst, root)
end

return RibopodBrain
