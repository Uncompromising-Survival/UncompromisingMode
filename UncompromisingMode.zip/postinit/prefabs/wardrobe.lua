local env = env
GLOBAL.setfenv(1, GLOBAL)

local function onopen(inst)
    if not inst:HasTag("burnt") then
        inst.AnimState:PlayAnimation("open")
        inst.SoundEmitter:PlaySound("dontstarve/common/wardrobe_open")
    end
end

local function onclose(inst)
    if not inst:HasTag("burnt") then
        inst.AnimState:PlayAnimation("cancel")
        inst.AnimState:PushAnimation("closed", false)
        inst.SoundEmitter:PlaySound("dontstarve/common/wardrobe_close")
    end
end

--[[local function ChangeIn(inst, doer)
    if inst.components.wardrobe then
        inst.components.wardrobe:BeginChanging(doer)
    end
end

local function OnStopChanneling(inst)
    if inst.channeler then
        --inst.channeler.sg:GoToState("idle")
    end
    inst.channeler = nil
end

local function GetActivateVerb(inst)
    return "OPEN"
end]]

env.AddPrefabPostInit("wardrobe", function(inst)
    inst:AddTag("dressable")--tag needed for m2 dress action.

    if not TheWorld.ismastersim then
        return
    end

    inst:AddComponent("container")
    inst.components.container:WidgetSetup("wardrobe")
    inst.components.container.skipclosesnd = true
    inst.components.container.skipopensnd = true

    inst.components.container.onopenfn = onopen
    inst.components.container.onclosefn = onclose

    --[[inst:AddComponent("channelable")
    inst.components.channelable:SetChannelingFn(ChangeIn, OnStopChanneling)
    inst.components.channelable.use_channel_longaction_noloop = true
    --inst.components.channelable.skip_state_stopchanneling = true
    inst.components.channelable.skip_state_channeling = true
    --inst.components.channelable.ignore_prechannel = true

    inst.GetActivateVerb = GetActivateVerb]]

    local _OnHit = inst.components.workable.onwork
    local _OnFinish = inst.components.workable.onfinish
    local function onhit(inst, worker)
        if inst.components.container then
            inst.components.container:DropEverything()
            inst.components.container:Close()
        end
        _OnHit(inst, worker)
    end

    local function onhammered(inst, worker)
        if inst.components.container then
            inst.components.container:DropEverything()
        end
        _OnFinish(inst, worker)
    end

    inst.components.workable:SetOnWorkCallback(onhit)
    inst.components.workable:SetOnFinishCallback(onhammered)
    --[[inst:ListenForEvent("onburnt", function()
        if inst.components.channelable then
            inst.components.channelable.enabled = false
        end
    end)]]

    inst:SetPhysicsRadiusOverride(0)
    MakeObstaclePhysics(inst, 0)
end)

--[[STRINGS.ACTIONS.STARTCHANNELING.WARDROBE = "Use"

ACTIONS.STARTCHANNELING.strfn = function(act)
    if act.target and act.target:HasTag("pump") then
        return "PUMP"
    elseif act.target and act.target:HasTag("wardrobe") then
        return "WARDROBE"
    else
        return nil
    end
end]]