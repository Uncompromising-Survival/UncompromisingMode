local env = env
GLOBAL.setfenv(1, GLOBAL)
------------------------------------------------------------------------------------------
local function NoHoles(pt)
    return not TheWorld.Map:IsPointNearHole(pt)
end

local function TentacleErupt(inst, owner, target)
    local pt
    if target ~= nil and target:IsValid() then
        pt = target:GetPosition()
    else
        pt = owner:GetPosition()
        target = nil
    end
    local offset = FindWalkableOffset(pt, math.random() * 2 * PI, 2, 3, false, true, NoHoles, false, true)
    if offset ~= nil then
        inst.SoundEmitter:PlaySound("dontstarve/common/shadowTentacleAttack_1")
        inst.SoundEmitter:PlaySound("dontstarve/common/shadowTentacleAttack_2")
        local tentacle = SpawnPrefab("shadowtentacle")
        if tentacle ~= nil then
            tentacle.Transform:SetPosition(pt.x + offset.x, 0, pt.z + offset.z)
            tentacle.components.combat:SetTarget(target)
            tentacle.ruinsbat = inst
            tentacle.ruinsbatowner = owner
        end
    end
end

local function HasSkill(inst, name)
    return inst.components.skilltreeupdater and inst.components.skilltreeupdater:IsActivated(name)
end

local function NewOnAttack(inst, attacker, target)
    if target and target.components.combat and target.components.combat.defaultdamage > 0 then
        if target.components.combat.ruinsbatstack then
            target.components.combat.ruinsbatstack = target.components.combat.ruinsbatstack + 1
            if target.components.combat.ruinsbatstack > 3.1 or (HasSkill(attacker, "ancient_kinship_2") and math.random() > 0.5) then
                TentacleErupt(inst, attacker, target)
                target.components.combat.ruinsbatstack = nil
            end
        else
            target.components.combat.ruinsbatstack = 1
        end
    end
    if attacker:HasTag("wathom") and attacker.components.adrenaline and HasSkill(attacker, "ancient_kinship_2") then
        attacker.components.adrenaline:DoDelta(3)
    end

    --inst.components.weapon.attackwear = target ~= nil and target:IsValid()
        --and target:HasTag("lunar_aligned")
        --and TUNING.GLASSCUTTER.SHADOW_WEAR
        --or 1
end


env.AddPrefabPostInit("ruins_bat", function(inst)
    if not TheWorld.ismastersim then
        return
    end

    if inst.components.weapon ~= nil then
        inst.components.weapon:SetOnAttack(NewOnAttack) --The old one doesn't have anything that's really useful to this new version. Replacing.
    end

    inst:AddComponent("damagetypebonus")
    inst.components.damagetypebonus:AddBonus("lunar_aligned", inst, 1 + 17 / 59)

    --local uses = 300
    --inst.components.finiteuses:SetMaxUses(uses)
    --inst.components.finiteuses:SetUses(uses)
end)
